/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DistanceEducation;

import java.sql.*;
import javax.swing.*;

/**
 *
 * @author User
 */
public class MySqlConnect {
    Connection conn=null;
    public static Connection ConnectDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/info?autoReconnect=true&useSSL=false","root","#mnimjm#");
            return conn;
        }
    catch(Exception e){
    JOptionPane.showMessageDialog(null,e);
    return null;
}
}
}
